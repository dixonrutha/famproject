<?php $__env->startSection('content'); ?>
<div class="p-3">
   <div class="table-responsive-md" style="background-color:aliceblue">
    <table class="table table-bordered">
        <thead>
            <tr class="table-primary">
                <th>#</th>
                <th>name</th>
                <th>sex</th>
                <th>tarehe kupokea</th>
                <th>njia_kupokea</th>
                <th>Email</th>
                <th>simu</th>
                <th>eneo_analoishi</th>
                <th>muda alio ishi</th>
                <th>makazi</th>
                <th>mengine</th>
                <th>U.jina</th>
                <th>U.cheo</th>
                <th>U.tarehe</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <th scope="row"><?php echo e($key+1); ?></th>
                <td><?php echo e($d->name); ?></td>
                <td><?php echo e($d->sex); ?></td>
                <td><?php echo e($d->tarehe_kupokea); ?></td>
                <td><?php echo e($d->njia_kupokea); ?></td>
                <td><?php echo e($d->email); ?></td>
                <td><?php echo e($d->simu); ?></td>
                <td><?php echo e($d->eneo_analoishi); ?></td>
                <td><?php echo e($d->muda_kuishi); ?></td>
                <td><?php echo e($d->makazi); ?></td>
                <td><?php echo e($d->mengine); ?></td>
              
                <td><?php echo e($d->jina); ?></td>
                <td><?php echo e($d->cheo); ?></td>
                <td><?php echo e($d->tarehe); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/private/mitz/simple_project/resources/views/home.blade.php ENDPATH**/ ?>